import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../../user.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  cartCount: any = 0;
  restaurantsName: string = "tapti bhojnalay";

  constructor(private router: Router, private userService: UserService) {
  }

  ngOnInit() {

    if(parseInt(localStorage.getItem('cartCount'))>0)
    {
      var str = localStorage.getItem('cartCount')
      var num = parseInt(str); //by using the parseInt operation 
      this.cartCount = num;
    }

    this.userService.foodName.subscribe(data => {
      if (data != 'food' && data != null) {
        var splitted = data.split(",");
        this.cartCount = splitted.length;
        localStorage.setItem('cartCount', this.cartCount)
      }
    });
  }

  cart() {

    this.router.navigate(['/cart']);
  }

  search(searchInput)
  {
    this.userService.sendSearchValue(searchInput.value);
    this.router.navigate(['hotel/'+this.restaurantsName]);
  }

}


