import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router'
import { item } from './Order.Item';
import { UserService } from '../../user.service';
import { records } from '../../entity/product';

@Component({
  selector: 'app-offers',
  templateUrl: './offers.component.html',
  styleUrls: ['./offers.component.css']
})
export class OffersComponent implements OnInit {
  value : number =300000;
  amount : number=9;
  imgUrl:string;
  i=1;
  imageArray:Array<string>=[];
  products:Array<records>=[];
  productsToAddinCart:Array<records>=[];
  public itemObject:item=new item();
  constructor(private router: Router,private service:UserService) { }

  ngOnInit() {

    this.service.getAllProducts().subscribe(result => {
      this.products=result['records'];
      for(let index=0;index<this.products.length;index++)
      {
        this.imageArray[index]="assets/images/"+(index+1)+".png";
      }
      
    });

    this.itemObject.add='1';
    this.itemObject.business="";
    this.itemObject.discount_amount='300';
    this.itemObject.currency_code="$";
    this.itemObject.return="";
    this.itemObject.cancel_return="";
    this.itemObject.item_name='dogs food';
    this.itemObject.amount="60000";

    this.amount=9000;
    
  }

  onClick(value:any)
  {
    console.log()
  }

  singleProduct(product,picIndex)
  {
    product.src="assets/images/"+(picIndex+1)+".png";
    this.service.sendSingleProductToOtherComponent(product);
    this.router.navigate(['/single']);
  }
  addProduct(product : any)
  {
    this.productsToAddinCart[this.productsToAddinCart.length]=product;
    this.service.sendPrductToOtherComponent(this.productsToAddinCart);
  }
  addtocart(){
    this.router.navigate(['/dashboard']);
  
  }
}
