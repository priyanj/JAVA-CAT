export class TaptiBhojnalayFood{
    foodName:String;
    foodPrice:Number;
    veg:boolean;
}