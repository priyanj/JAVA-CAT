export class records {
    id:number;
    name:string;
    description:string;
    price:number;
    category_id:number;
    category_name:string;
    src:string;
}