import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../user.service';

@Component({
  selector: 'app-single',
  templateUrl: './single.component.html',
  styleUrls: ['./single.component.css']
})
export class SingleComponent implements OnInit {

  product:any;
  imageArray:Array<string>=[];

  constructor(private router: Router, private service:UserService) { }

  ngOnInit() {
    
    this.service.singleProduct.subscribe(data => {
      this.product=data;
      this.imageArray[0]=this.product.src;
    });
  }

}
