import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BannerComponent } from './banner.component';
import { SliderComponent } from '../slider/slider.component';

@NgModule({
  declarations: [],
  imports: [
    CommonModule
  ]
})
export class BannerModule { }
