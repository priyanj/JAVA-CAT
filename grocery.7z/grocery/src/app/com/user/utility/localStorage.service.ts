import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Observable, BehaviorSubject } from 'rxjs';
import { records } from '../entity/product';

@Injectable({
  providedIn: 'root'
})
export class LocalStorageService {

  constructor(private http:HttpClient) { }

  setLoggedInTrue(isLoggedin : string){
    localStorage.setItem('isLoggedin',isLoggedin);
  }

  getdomainURL(){
    localStorage.setItem('domainURL','http://glintel.com/api');
    return localStorage.getItem('domainURL');
  }
  
  setRecordObject(user : Object){
    localStorage.setItem('records',JSON.stringify(user));
  }

  getRecordObject() : records{
    return JSON.parse(localStorage.getItem('records'));
  }
}
