import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../../user.service';
import { records } from '../../entity/product';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  products:any
  productCount=0;
  constructor(private router: Router, private service:UserService) { 
  }

  ngOnInit() {

    this.service.productData.subscribe(data => {
      this.products=data;
      this.productCount=this.products.length;
    });
   
  }

  cart()
    {
      this.service.sendPrductToOtherComponent(this.products);
      console.log("^^^^^^^^^^^^^^^^^^^^^^^^")
      this.router.navigate(['/cart']);
    }

}


