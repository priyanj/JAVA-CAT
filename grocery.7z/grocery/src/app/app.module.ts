import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
// import { HeaderComponent } from './com/user/includes/header/header.component';
// import { FooterComponent } from './com/user/includes/footer/footer.component';
// import { SidenavComponent } from './com/user/includes/sidenav/sidenav.component';
// import { BannerComponent } from './com/user/includes/banner/banner.component';
// import { SliderComponent } from './com/user/includes/slider/slider.component';
// import { VegitablesComponent } from './com/user/vegitables/vegitables.component';
// import { OffersComponent } from './com/user/includes/offers/offers.component';
// import { DiscountComponent } from './com/user/includes/discount/discount.component';
// import { CopyrightComponent } from './com/user/includes/copyright/copyright.component';
// import { NavbarComponent } from './com/user/includes/navbar/navbar.component';
// import { UserComponent } from './com/user/user.component';
//import { HttpClientModule} from '@angular/common';


@NgModule({
  declarations: [
   AppComponent
  ],
  imports: [
  BrowserModule,
   AppRoutingModule,
   HttpClientModule,
   FormsModule,
   RouterModule.forRoot([])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
