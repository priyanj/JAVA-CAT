import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vegitables',
  templateUrl: './vegitables.component.html',
  styleUrls: ['./vegitables.component.css']
})
export class VegitablesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
