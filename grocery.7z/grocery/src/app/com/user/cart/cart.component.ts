import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../user.service';


@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  products:any
  productCount=0;
  imageArray:Array<string>=[];
  constructor(private router: Router, private service:UserService) { 
  }

  ngOnInit() {
    this.service.productData.subscribe(data => {
      
      this.products=data;
      this.productCount=this.products.length;
      console.log(this.products)
    });

    for(let index=0;index<this.products.length;index++)
      {
        this.imageArray[index]="assets/images/"+(index+1)+".png";
      }
      
   
  }

  singleProduct(product,picIndex)
  {
    product.src="assets/images/"+(picIndex+1)+".png";
    this.service.sendSingleProductToOtherComponent(product);
    this.router.navigate(['/single']);
  }


}
