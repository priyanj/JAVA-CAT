export class item{

    cart:string;
    add :string;
    business:string;
    item_name:string;
    amount:string;
    discount_amount:string;
    currency_code:string;
    return:string;
    cancel_return:string;
}