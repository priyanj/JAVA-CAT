import { Injectable } from '@angular/core';
import { LocalStorageService } from './utility/localStorage.service';
import {HttpClient, HttpHeaders, HttpErrorResponse} from '@angular/common/http';
import { Observable, BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http: HttpClient,private myStorage:LocalStorageService) { }

  getAllProducts() {
    return  this.http.get(this.myStorage.getdomainURL()+`/product/read.php`);
  }

  getSingleProduct(){
    return  this.http.get(this.myStorage.getdomainURL()+`/product/read_one.php?id=60`);
  }

  private comptransfer = new BehaviorSubject("default");
    productData= this.comptransfer.asObservable();
  
    sendPrductToOtherComponent(messsage){
        this.comptransfer.next(messsage);
    }
    
    singleProduct= this.comptransfer.asObservable();
  
    sendSingleProductToOtherComponent(messsage){
        this.comptransfer.next(messsage);
    } 
}
