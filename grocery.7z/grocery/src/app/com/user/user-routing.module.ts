import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UserComponent } from './user.component';

const routes: Routes = [

  {
    path: '',
    component:UserComponent,
    children: [
    { path: '', redirectTo: 'dashboard' },
    { path: 'dashboard', loadChildren: './dashboard/dashboard.module#DashboardModule' },
    { path: 'aboutus', loadChildren: './aboutus/aboutus.module#AboutusModule' },
    { path: 'deal', loadChildren: './deals/deals.module#DealsModule' },
    { path: 'event', loadChildren: './events/events.module#EventsModule' },
    { path: 'service', loadChildren: './services/services.module#ServicesModule' },
    { path: 'single', loadChildren: './single/single.module#SingleModule' },
    { path: 'cart', loadChildren: './cart/cart.module#CartModule' }
  
    ]
    
    } 
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UserRoutingModule { }
